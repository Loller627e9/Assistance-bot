// main.js
const { Client, GatewayIntentBits, EmbedBuilder, Partials } = require('discord.js');
const fs = require('fs');
const { spawnGrinders } = require('./grinder');
const { handleCommands } = require('./handlers');
const access = require('./storage/access.json');
const tokens = require('./storage/tokens.json');

const prefix = "$";
const OWNER_ID = access.admins[0];

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent],
  partials: [Partials.Channel]
});

client.once("ready", () => {
  console.log(`✅ Assistance is live as ${client.user.tag}`);
  spawnGrinders();
});

client.on("messageCreate", async (msg) => {
  if (!msg.content.startsWith(prefix) || msg.author.bot) return;
  if (![OWNER_ID, ...(access.admins || [])].includes(msg.author.id)) return;
  await handleCommands(msg);
});

client.login("MTM5MjE1ODUyMTkwMjEwODc0NQ.Gp6-Zz.6TPVYKxWnJoD9BnRUMCyAzaWDinXUHeXhmjHgE");
