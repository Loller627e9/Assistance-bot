const fs = require('fs');
const { EmbedBuilder } = require('discord.js');
let tokens = require('./storage/tokens.json');
let stats = require('./storage/stats.json');
let access = require('./storage/access.json');

function save(file, data) {
  fs.writeFileSync(`./storage/${file}.json`, JSON.stringify(data, null, 2));
}

async function handleCommands(msg) {
  const args = msg.content.slice(1).trim().split(/ +/);
  const cmd = args.shift().toLowerCase();

  if (cmd === "help") {
    const help = new EmbedBuilder()
      .setColor(0x2f3136)
      .setTitle("📘 Assistance Help Menu")
      .setDescription("```plaintext\n• stats\n• add-token <token> <channel>\n• remove-token <id>\n• toggle <id>\n• start-all / stop-all\n• grant / revoke <@user>\n• reset-stats\n• export-stats\n```")
      .setFooter({ text: "MADE WITHOUT LOVE BY SOMEONE1284 ❤️" });
    msg.reply({ embeds: [help] });
  }

  if (cmd === "stats") {
  let totalCommands = 0, totalCoins = 0, totalCatches = 0, totalItems = 0, totalFails = 0, totalAnimals = 0;

  let rows = tokens.map((t, i) => {
    const s = stats[t.token] || {};
    totalCommands += s.commands || 0;
    totalCoins += s.coins || 0;
    totalCatches += s.catches || 0;
    totalItems += s.items || 0;
    totalFails += s.failures || 0;
    totalAnimals += s.animals || 0;

    return `#${i} • ${s.name || "Unknown"} • Cmds: ${(s.commands || 0).toLocaleString()} • Coins: ${(s.coins || 0).toLocaleString()} • Catches: ${(s.catches || 0).toLocaleString()} • Animals: ${(s.animals || 0).toLocaleString()} • Items: ${(s.items || 0).toLocaleString()} • Fails: ${(s.failures || 0).toLocaleString()} • ${t.active ? "🟢" : "🔴"}`;
  }).join("\n");

  const embed = new EmbedBuilder()
    .setColor(0x2f3136)
    .setTitle("📊 Broskie Stats")
    .setDescription("```plaintext\n" + rows + "\n```\n" +
      `💰 Coins: ${totalCoins.toLocaleString()} | 🐾 Catches: ${totalCatches.toLocaleString()} | 🐇 Animals: ${totalAnimals.toLocaleString()} | 📦 Items: ${totalItems.toLocaleString()} | ⚙️ Commands: ${totalCommands.toLocaleString()} | ❌ Failures: ${totalFails.toLocaleString()}`);
  msg.reply({ embeds: [embed] });
}

  if (cmd === "add-token" && args.length === 2) {
    tokens.push({ token: args[0], channelId: args[1], active: true });
    save("tokens", tokens);
    msg.reply("✅ Token added.");
  }

  if (cmd === "remove-token" && args[0]) {
    const i = parseInt(args[0]);
    if (isNaN(i) || !tokens[i]) return msg.reply("❌ Invalid token ID.");
    tokens.splice(i, 1);
    save("tokens", tokens);
    msg.reply("🗑️ Token removed.");
  }

  if (cmd === "toggle" && args[0]) {
    const i = parseInt(args[0]);
    if (isNaN(i) || !tokens[i]) return msg.reply("❌ Invalid token ID.");
    tokens[i].active = !tokens[i].active;
    save("tokens", tokens);
    msg.reply(`🔁 Token #${i} toggled to ${tokens[i].active ? "🟢 Active" : "🔴 Inactive"}.`);
  }

  if (cmd === "start-all") {
    tokens.forEach(t => t.active = true);
    save("tokens", tokens);
    msg.reply("▶️ All broskies started.");
  }

  if (cmd === "stop-all") {
    tokens.forEach(t => t.active = false);
    save("tokens", tokens);
    msg.reply("⏹️ All broskies stopped.");
  }

  if (cmd === "grant" && args[0]) {
    const id = args[0].replace(/[<@!>]/g, "");
    if (!access.admins.includes(id)) access.admins.push(id);
    save("access", access);
    msg.reply("✅ Access granted.");
  }

  if (cmd === "revoke" && args[0]) {
    const id = args[0].replace(/[<@!>]/g, "");
    access.admins = access.admins.filter(u => u !== id);
    save("access", access);
    msg.reply("❌ Access revoked.");
  }

  if (cmd === "reset-stats") {
    stats = {};
    save("stats", stats);
    msg.reply("📉 Stats reset.");
  }

  if (cmd === "export-stats") {
    msg.channel.send({ files: ["./storage/stats.json"] });
  }
}

module.exports = { handleCommands };
