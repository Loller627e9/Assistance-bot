# 🤖 Assistance - Dank Memer Grinder Bot

## 📦 What is This?
**Assistance** is a Discord bot that:
- Disguises itself as a utility/music bot
- Runs a full multi-token Dank Memer farming system in the background
- Tracks coins, items, catches, and commands per account
- Provides admin-only commands using the `$` prefix

---

## 🧠 Features
- 💰 Coins tracked using `pls bal`
- 🐾 Catches tracked from `pls hunt` replies
- 📦 Items tracked from messages containing `found`
- ⚙️ Command logs and error tracking
- 🧍‍♂️ Multi-token support with toggle per broskie
- 📊 Stylish `$stats` embeds like Broskie bots

---

## 🛠 Setup Instructions

1. Install dependencies:
```bash
npm install discord.js discord.js-selfbot-v13
```

2. Update the following:
- In `index.js`, replace `YOUR_BOT_TOKEN` with your real Discord bot token
- In `storage/access.json`, replace `YOUR_DISCORD_ID` with your Discord user ID

3. Add your broskie tokens using the `$add-token` command:
```bash
$add-token your_user_token your_channel_id
```

4. Start the bot:
```bash
node index.js
```

---

## 📁 File Structure
```
AssistanceBot/
├── index.js              # Main bot controller
├── grinder.js            # Dank Memer farming logic
├── handlers.js           # $commands and UI logic
└── storage/
    ├── access.json       # Who can use $commands
    ├── tokens.json       # List of user tokens and channels
    ├── stats.json        # Tracked stats (auto-updates)
```

---

## 🔐 Admin Commands
All commands use `$` prefix and are restricted to admins listed in `access.json`.

```
$help            Show all commands
$stats           View real-time stats
$add-token       Add new broskie (token + channel)
$remove-token    Remove broskie by ID
$toggle          Pause/resume a specific broskie
$start-all       Resume all broskies
$stop-all        Pause all broskies
$grant           Grant admin to another user
$revoke          Revoke admin from user
$reset-stats     Clear all stats
$export-stats    Send stats.json to chat
```

---

## ✅ Verified for:
- Bot-hosting.net
- Replit
- Termux (with Node.js)
- VPS

---

## 💬 Created with love by Someone1284
