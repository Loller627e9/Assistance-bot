const fs = require('fs');
const { Client } = require('discord.js-selfbot-v13');
const stats = require('./storage/stats.json');
const tokens = require('./storage/tokens.json');

const logFile = 'sent_commands.log';
const saveStats = () => fs.writeFileSync('./storage/stats.json', JSON.stringify(stats, null, 2));

function log(msg) {
  const timestamp = new Date().toISOString();
  fs.appendFileSync(logFile, `[${timestamp}] ${msg}\n`);
}

function spawnGrinders() {
  tokens.forEach((account, index) => {
    if (!account.token || !account.channelId || account.active === false || account.token.length < 30) {
      console.log(`⚠️ Skipping token at index #${index} (missing or invalid)`);
      return;
    }

    const client = new Client();

    client.on('ready', () => {
      console.log(`✅ Logged in as ${client.user.tag}`);
      const channel = client.channels.cache.get(account.channelId);
      if (!channel) {
        console.log(`❌ Channel ${account.channelId} not found`);
        return;
      }

      stats[account.token] = stats[account.token] || {
        name: "",
        commands: 0,
        coins: 0,
        catches: 0,
        items: 0,
        animals: 0,
        failures: 0,
        lastTotal: 0
      };

      stats[account.token].name = client.user.tag;
      saveStats();

      const loop = async () => {
        while (true) {
          const cmds = ['pls beg', 'pls hunt', 'pls dig', 'pls bal'];
          for (const cmd of cmds) {
            try {
              await channel.send(cmd);
              stats[account.token].commands += 1;
              log(`${client.user.username} ➤ Sent: ${cmd}`);
            } catch (err) {
              stats[account.token].failures = (stats[account.token].failures || 0) + 1;
              log(`${client.user.username} ⚠️ Error: ${err.message}`);
            }
            saveStats();
            await new Promise(r => setTimeout(r, 3000));
          }
          await new Promise(r => setTimeout(r, 45000));
        }
      };

      loop();
    });

    client.on("messageCreate", (msg) => {
      if (msg.author.id !== "270904126974590976") return;
      const s = stats[account.token];

      // Coin tracking via embed emoji lines
      if (msg.embeds && msg.embeds[0] && msg.embeds[0].description) {
        const desc = msg.embeds[0].description;
        const walletMatch = desc.match(/<:Coin:1105833876032606350>\s([\d,]+)/);
        const bankMatch = desc.match(/<:Bank:1070046716096688218>\s([\d,]+)\s\//);

        if (walletMatch && bankMatch) {
          const wallet = parseInt(walletMatch[1].replace(/,/g, ''));
          const bank = parseInt(bankMatch[1].replace(/,/g, ''));
          const total = wallet + bank;

          const old = s.lastTotal || 0;
          if (total > old) s.coins += (total - old);
          s.lastTotal = total;
        }
      }

      // Catch detection (from pls hunt)
      if (msg.content.toLowerCase().includes("caught a")) {
        s.catches += 1;
      }

      // Animal detection (from hunt)
      if (msg.content.includes("You went hunting and brought back **1")) {
        s.animals += 1;
      }

      // Item detection (from dig)
      if (msg.content.includes("You dug in the dirt and brought back **1")) {
        s.items += 1;
      }

      saveStats();
    });

    client.login(account.token).catch(err => {
      const masked = account.token.slice(0, 10) + '...';
      log(`❌ Login failed for token [${masked}] — ${err.message}`);
      console.log(`❌ Login failed for token [${masked}] — ${err.message}`);
    });
  });
}

module.exports = { spawnGrinders };
